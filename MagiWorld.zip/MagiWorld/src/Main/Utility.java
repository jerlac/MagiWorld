package Main;

class Utility {
    /**
     * Ecrit le message sur la console
     * @param msg le message
     */
    static void writeMsg(String msg){
        System.out.println(String.format(msg));
    }
}
